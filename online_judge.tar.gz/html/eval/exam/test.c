#include<stdio.h>
int main()
{
    int j;
for(j=0;j<10000000;j++){
    printf("1\n");
}
return 0;
}
