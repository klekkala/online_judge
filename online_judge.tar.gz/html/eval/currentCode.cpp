
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<cmath>

#include<algorithm>
#include<iostream>
#include<string>
#include<vector>
#include<map>

using namespace std;
typedef long long int LL;

int main()
{
	LL t,a,b;
	cin>>t;
	while(t--)
	{
		cin>>a>>b;
		cout<<a+b<<endl;
	}
	return 0;
}
