fd=open("test.html","r")
print fd.readlines()
